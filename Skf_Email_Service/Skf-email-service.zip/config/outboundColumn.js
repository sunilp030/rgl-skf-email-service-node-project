const outboundColumn = [
    "HLBINL",
    "HLQYAL",
    "HHBXNR",
    "HLCONR",
    "HHDIRP",
    "HLCOLI",
    "HLCOLS",
    "CHCOON",
    "PRDSGN",
    "HLPCID",
    "HLCMFG",
    "HHDPIC",
    "HLPKST",
    "HHPKST",
    "HHCUID",
    "HHNNNB",
    "HHWTOP",
    "HHADR1",
    "CHUNTA",
    "HHADR2",
    "HHADR3",
    "HHADR4",
    "HLBSQA",
    "HHTPTN",
    "HHJBCE",
    "HHMMNB",
    "HLWLWT",
    "CHLONR",
    "CHIVNR",
    "CHWGHT",]
module.exports = outboundColumn;




